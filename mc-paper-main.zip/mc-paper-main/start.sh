#!/bin/bash
java -Xms1G -Xmx1G -jar paper-1.21.4-123.jar nogui
